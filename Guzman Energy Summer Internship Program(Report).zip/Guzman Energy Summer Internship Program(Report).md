## Assignment 1: Power Calendar function


```python
import holidays
import re
from datetime import datetime
from datetime import timedelta 
import calendar
```


```python
def get_hours(iso,peak_type,period):
    
    #This part use regular expression to class the input period and output the start and end date for the given period
    pattern1 = "([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})"
    pattern2 = "([0-9]{4})(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
    pattern3 = "([0-9]{4})(Q)([1-4])"
    pattern4 = "([0-9]{4})A"
    
    if re.sub(pattern1,'1',period)=='1':
        year=re.sub(pattern1,'\\1',period)
        start_date=period
        end_date=period
    elif re.sub(pattern2,'1',period)=='1':
        year=re.sub(pattern2,'\\1',period)
        month=re.sub(pattern2,'\\2',period)
        month_number = datetime.strptime(month, '%b').month 
        _, num_days = calendar.monthrange(int(year), month_number)
        start_date=year+"-"+str(month_number)+"-1"
        end_date=year+"-"+str(month_number)+"-"+str(num_days)
    elif re.sub(pattern3,'1',period)=='1':
        year=re.sub(pattern3,'\\1',period)
        quater=re.sub(pattern3,'\\3',period)
        if quater==1:
            start_date=year+"-1-1"
            end_date=year+"-3-31"
        elif quater==2:
            start_date=year+"-4-1"
            end_date=year+"-6-30"
        elif quater==3:
            start_date=year+"-7-1"
            end_date=year+"-9-30"
        else:
            start_date=year+"-10-1"
            end_date=year+"-12-31"
    elif re.sub(pattern4,'1',period)=='1':
        year=re.sub(pattern4,'\\1',period)
        start_date=year+"-1-1"
        end_date=year+"-12-31"
    start_date=datetime.strptime(start_date, '%Y-%m-%d').date()
    end_date=datetime.strptime(end_date, '%Y-%m-%d').date()
    year = int(year)
    nerc_holidays = holidays.US(years=year, observed=True)

    #This part determine which region we choose
    if iso in ["PJMISO", "MISO","ERCOT", "SPPISO", "NYISO"]:
        param=5
    else:
        param=6
        
    #This part is where we calculate number of hours
    if peak_type in ["onpeak","offpeak","flat"]:
        onpeak_hour=0
        flat_hour=0
        current_datetime = start_date
        while current_datetime <= end_date:
            current_datetime += timedelta(days=1)
            flag=False
            for date, name in nerc_holidays.items():
                if current_datetime.weekday()<param and date!=current_datetime:
                    flag=True
            if flag==True:
                onpeak_hour+=16
            flat_hour+=24
        offpeak_hour=flat_hour-onpeak_hour
        if peak_type=="onpeak":
            num_hour=onpeak_hour
        elif peak_type=="offpeak":
            num_hour=offpeak_hour
        elif peak_type=="flat":
            num_hour=flat_hour
    elif peak_type=="2*16H":
        num_hour=0
        current_datetime = start_date
        while current_datetime <= end_date:
            current_datetime += timedelta(days=1)
            flag=False
            for date, name in nerc_holidays.items():
                if current_datetime.weekday()>=param or date==current_datetime:
                    flag=True
            if flag==True:
                num_hour+=16
    elif peak_type=="7*8":
        num_hour=0
        current_datetime = start_date
        while current_datetime <= end_date:
            current_datetime += timedelta(days=1)
            num_hour+=8
            
    return([iso,peak_type,start_date,end_date,num_hour])
```

    To calculate the number of hours, we need to first figure what is the type of input. There are four type of period input. We use regular expression of classify the input period and at the same time, extract the information from the input to obtain the start and end date. After this, we can calcuate the number of hours based on the peak input. Here is where I find a pattern. The flat hour is the sum of onpeak and offpeak hours. Meaning if we can find onpeak hour. We can easliy obtain offpeak hour as well. The flat hour is simply 24 times the number of days. For onpeak hour, we need to filter the days which is not weekend or holiday. After that mutiply the number of days by 16 will give us the result. Finally, the offpeak hour can be calculated by the flat hour minus the onpeak hour. For 2 * 16H type. We need to find days that is either weekend or holiday, then mutiply the number of days by 16. For 7 * 8. We simply mutiply total number of days by 8. Also, the small difference between Estern and Western region and be solved by adding a parameter to classify weekdays. 

## Assignment 2: Meter Data formatting


```python
import pandas as pd
```


```python
# import and clean both dataset
df1 = pd.read_csv ('Assignment 2 - new.app4.csv')
df1 = df1.drop(columns="Unnamed: 0")
df1=df1.rename(columns={'time': 'DateTime'})
df1["W_min"]=df1["W_min"]/1000
df1['DateTime'] = pd.to_datetime(df1['DateTime'], format='%m/%d/%Y %H:%M')
df1['DateTime'] = df1['DateTime'].dt.floor('H')
df1 = df1.groupby(df1['DateTime'])['W_min'].sum().reset_index()
df2 = pd.read_csv ('Assignment 2 - USA_AL_Auburn-Opelika.AP.722284_TMY3_BASE.csv')
df2=df2.rename(columns={'Date/Time': 'DateTime'})
for i in range(len(df1["DateTime"])):
    output = df1.loc[i,"DateTime"].strftime('%m/%d %H:%M')
    df1.loc[i,"DateTime"]=output
pattern = "(.*)(24:00:00)"
for i in range(len(df2["DateTime"])):
    if re.sub(pattern,'1',df2.loc[i,"DateTime"])=='1':
        df2.loc[i,"DateTime"]=re.sub(pattern,'\\1',df2.loc[i,"DateTime"])+"00:00:00"
        date_time = datetime.strptime(df2.loc[i,"DateTime"].lstrip(), '%m/%d %H:%M:%S')
        next_day = date_time + timedelta(days=1)
        out = next_day.strftime('%m/%d %H:%M')
        df2.loc[i,"DateTime"]=out
    else:    
        date_time = datetime.strptime(df2.loc[i,"DateTime"].lstrip(), '%m/%d %H:%M:%S')
        out = date_time.strftime('%m/%d %H:%M')
        df2.loc[i,"DateTime"]=out
```

We start by preprocessing the data. For the new.app4 data. We need to turn the data into hourly so that the datetime could match the other dataset. For the USA_AL_Auburn-Opelika.AP.722284_TMY3_BASE data. We need to modify the datetime to have the same shape. Also, some data contain time like 24:00:00 which is not supported by python datetime structing. We have the change those to 00:00:00 for the next day. Here is the data after we preprocess.


```python
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>W_min</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>06/07 11:00</td>
      <td>57.388943</td>
    </tr>
    <tr>
      <th>1</th>
      <td>06/07 12:00</td>
      <td>27.227961</td>
    </tr>
    <tr>
      <th>2</th>
      <td>06/07 13:00</td>
      <td>111.476298</td>
    </tr>
    <tr>
      <th>3</th>
      <td>06/07 14:00</td>
      <td>109.021960</td>
    </tr>
    <tr>
      <th>4</th>
      <td>06/07 15:00</td>
      <td>5.773963</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>Electricity:Facility [kW](Hourly)</th>
      <th>Gas:Facility [kW](Hourly)</th>
      <th>Heating:Electricity [kW](Hourly)</th>
      <th>Heating:Gas [kW](Hourly)</th>
      <th>Cooling:Electricity [kW](Hourly)</th>
      <th>HVACFan:Fans:Electricity [kW](Hourly)</th>
      <th>Electricity:HVAC [kW](Hourly)</th>
      <th>Fans:Electricity [kW](Hourly)</th>
      <th>General:InteriorLights:Electricity [kW](Hourly)</th>
      <th>General:ExteriorLights:Electricity [kW](Hourly)</th>
      <th>Appl:InteriorEquipment:Electricity [kW](Hourly)</th>
      <th>Misc:InteriorEquipment:Electricity [kW](Hourly)</th>
      <th>Water Heater:WaterSystems:Electricity [kW](Hourly)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01/01 01:00</td>
      <td>0.974334</td>
      <td>4.452977</td>
      <td>0.0</td>
      <td>4.425010</td>
      <td>0.0</td>
      <td>0.112709</td>
      <td>0.112709</td>
      <td>0.112709</td>
      <td>0.154019</td>
      <td>0.033180</td>
      <td>0.092943</td>
      <td>0.406035</td>
      <td>0.158803</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01/01 02:00</td>
      <td>0.796582</td>
      <td>4.850317</td>
      <td>0.0</td>
      <td>4.824566</td>
      <td>0.0</td>
      <td>0.122617</td>
      <td>0.122617</td>
      <td>0.122617</td>
      <td>0.089845</td>
      <td>0.019355</td>
      <td>0.076186</td>
      <td>0.373851</td>
      <td>0.098084</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01/01 03:00</td>
      <td>0.735028</td>
      <td>5.037645</td>
      <td>0.0</td>
      <td>5.012193</td>
      <td>0.0</td>
      <td>0.127099</td>
      <td>0.127099</td>
      <td>0.127099</td>
      <td>0.064175</td>
      <td>0.013825</td>
      <td>0.062326</td>
      <td>0.369517</td>
      <td>0.081442</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01/01 04:00</td>
      <td>0.727433</td>
      <td>5.107562</td>
      <td>0.0</td>
      <td>5.082468</td>
      <td>0.0</td>
      <td>0.128391</td>
      <td>0.128391</td>
      <td>0.128391</td>
      <td>0.064175</td>
      <td>0.013825</td>
      <td>0.053976</td>
      <td>0.364315</td>
      <td>0.086107</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01/01 05:00</td>
      <td>0.778706</td>
      <td>5.270878</td>
      <td>0.0</td>
      <td>5.246732</td>
      <td>0.0</td>
      <td>0.132549</td>
      <td>0.132549</td>
      <td>0.132549</td>
      <td>0.064175</td>
      <td>0.013825</td>
      <td>0.065823</td>
      <td>0.350553</td>
      <td>0.135137</td>
    </tr>
  </tbody>
</table>
</div>



Then, I use the dfply the merge the two dataset by matching their datetime. Note the W_min column is divided by 1000 to match the unit with other columns. Here is the merged dataset.


```python
# Use dfply to merge the data by datetime
from dfply import *
merged_df = df1 >> inner_join(df2, by='DateTime')
merged_df['DateTime'] = pd.to_datetime(merged_df['DateTime'], format='%m/%d %H:%M')
for i in range(len(merged_df["DateTime"])):
    output = merged_df.loc[i,"DateTime"].strftime('%m/%d %H:%M')
    merged_df.loc[i,"DateTime"]=output
merged_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>W_min</th>
      <th>Electricity:Facility [kW](Hourly)</th>
      <th>Gas:Facility [kW](Hourly)</th>
      <th>Heating:Electricity [kW](Hourly)</th>
      <th>Heating:Gas [kW](Hourly)</th>
      <th>Cooling:Electricity [kW](Hourly)</th>
      <th>HVACFan:Fans:Electricity [kW](Hourly)</th>
      <th>Electricity:HVAC [kW](Hourly)</th>
      <th>Fans:Electricity [kW](Hourly)</th>
      <th>General:InteriorLights:Electricity [kW](Hourly)</th>
      <th>General:ExteriorLights:Electricity [kW](Hourly)</th>
      <th>Appl:InteriorEquipment:Electricity [kW](Hourly)</th>
      <th>Misc:InteriorEquipment:Electricity [kW](Hourly)</th>
      <th>Water Heater:WaterSystems:Electricity [kW](Hourly)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>06/07 11:00</td>
      <td>57.388943</td>
      <td>1.479426</td>
      <td>0.018757</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.347519</td>
      <td>0.100007</td>
      <td>0.447526</td>
      <td>0.100007</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.360615</td>
      <td>0.272322</td>
      <td>0.324996</td>
    </tr>
    <tr>
      <th>1</th>
      <td>06/07 12:00</td>
      <td>27.227961</td>
      <td>1.559733</td>
      <td>0.018441</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.454263</td>
      <td>0.130764</td>
      <td>0.585027</td>
      <td>0.130764</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.350008</td>
      <td>0.267735</td>
      <td>0.282996</td>
    </tr>
    <tr>
      <th>2</th>
      <td>06/07 13:00</td>
      <td>111.476298</td>
      <td>1.702835</td>
      <td>0.019079</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.603876</td>
      <td>0.169912</td>
      <td>0.773789</td>
      <td>0.169912</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.319024</td>
      <td>0.276993</td>
      <td>0.259063</td>
    </tr>
    <tr>
      <th>3</th>
      <td>06/07 14:00</td>
      <td>109.021960</td>
      <td>1.859094</td>
      <td>0.020153</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.752179</td>
      <td>0.211629</td>
      <td>0.963808</td>
      <td>0.211629</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.294229</td>
      <td>0.292590</td>
      <td>0.234500</td>
    </tr>
    <tr>
      <th>4</th>
      <td>06/07 15:00</td>
      <td>5.773963</td>
      <td>2.100629</td>
      <td>0.021274</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.921579</td>
      <td>0.253177</td>
      <td>1.174756</td>
      <td>0.253177</td>
      <td>0.050307</td>
      <td>0.010837</td>
      <td>0.301026</td>
      <td>0.308854</td>
      <td>0.238204</td>
    </tr>
  </tbody>
</table>
</div>




```python
#This function allow user to specify a given period
def get_df(month1,day1,hour1,month2,day2,hour2):
    _merged_df = df1 >> inner_join(df2, by='DateTime')
    _merged_df['DateTime'] = pd.to_datetime(merged_df['DateTime'], format='%m/%d %H:%M')
    start_time = datetime(1900,month1, day1, hour1, 0)
    end_time = datetime(1900,month2, day2, hour2, 59)
    filtered_df = _merged_df >> mask((X.DateTime >= start_time) & (X.DateTime <= end_time))
    return(filtered_df)
```


```python
filtered_df=get_df(6,10,11,7,15,23)
```

I also add another column that sum up all other columns as total energy consumption.


```python
#total_energy_consumption column is add which is the sum of all columns except for datetime
merged_df["total_energy_consumption"]=merged_df.drop("DateTime", axis=1).sum(axis=1)
merged_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateTime</th>
      <th>W_min</th>
      <th>Electricity:Facility [kW](Hourly)</th>
      <th>Gas:Facility [kW](Hourly)</th>
      <th>Heating:Electricity [kW](Hourly)</th>
      <th>Heating:Gas [kW](Hourly)</th>
      <th>Cooling:Electricity [kW](Hourly)</th>
      <th>HVACFan:Fans:Electricity [kW](Hourly)</th>
      <th>Electricity:HVAC [kW](Hourly)</th>
      <th>Fans:Electricity [kW](Hourly)</th>
      <th>General:InteriorLights:Electricity [kW](Hourly)</th>
      <th>General:ExteriorLights:Electricity [kW](Hourly)</th>
      <th>Appl:InteriorEquipment:Electricity [kW](Hourly)</th>
      <th>Misc:InteriorEquipment:Electricity [kW](Hourly)</th>
      <th>Water Heater:WaterSystems:Electricity [kW](Hourly)</th>
      <th>total_energy_consumption</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>06/07 11:00</td>
      <td>57.388943</td>
      <td>1.479426</td>
      <td>0.018757</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.347519</td>
      <td>0.100007</td>
      <td>0.447526</td>
      <td>0.100007</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.360615</td>
      <td>0.272322</td>
      <td>0.324996</td>
      <td>60.897441</td>
    </tr>
    <tr>
      <th>1</th>
      <td>06/07 12:00</td>
      <td>27.227961</td>
      <td>1.559733</td>
      <td>0.018441</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.454263</td>
      <td>0.130764</td>
      <td>0.585027</td>
      <td>0.130764</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.350008</td>
      <td>0.267735</td>
      <td>0.282996</td>
      <td>31.065016</td>
    </tr>
    <tr>
      <th>2</th>
      <td>06/07 13:00</td>
      <td>111.476298</td>
      <td>1.702835</td>
      <td>0.019079</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.603876</td>
      <td>0.169912</td>
      <td>0.773789</td>
      <td>0.169912</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.319024</td>
      <td>0.276993</td>
      <td>0.259063</td>
      <td>115.828105</td>
    </tr>
    <tr>
      <th>3</th>
      <td>06/07 14:00</td>
      <td>109.021960</td>
      <td>1.859094</td>
      <td>0.020153</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.752179</td>
      <td>0.211629</td>
      <td>0.963808</td>
      <td>0.211629</td>
      <td>0.047163</td>
      <td>0.010160</td>
      <td>0.294229</td>
      <td>0.292590</td>
      <td>0.234500</td>
      <td>113.919095</td>
    </tr>
    <tr>
      <th>4</th>
      <td>06/07 15:00</td>
      <td>5.773963</td>
      <td>2.100629</td>
      <td>0.021274</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.921579</td>
      <td>0.253177</td>
      <td>1.174756</td>
      <td>0.253177</td>
      <td>0.050307</td>
      <td>0.010837</td>
      <td>0.301026</td>
      <td>0.308854</td>
      <td>0.238204</td>
      <td>11.407785</td>
    </tr>
  </tbody>
</table>
</div>




```python
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
#Visualization
sns.barplot(x="DateTime", y="W_min", data=df1)
plt.gca().set_xticklabels([])
plt.title("Hourly Energy Consumption")
plt.show()
```


    
![png](output_17_0.png)
    



```python
df2['DateTime'] = pd.to_datetime(df2['DateTime'],format='%m/%d %H:%M')
df2["total_energy_consumption"]=df2.drop("DateTime", axis=1).sum(axis=1)
weekday_df = df2[df2['DateTime'].dt.weekday < 5]
```


```python
sns.barplot(x="DateTime", y="total_energy_consumption", data=weekday_df)
plt.gca().set_xticklabels([])
plt.title("Weekday Energy Consumption")
plt.show()
```


    
![png](output_19_0.png)
    



```python
monthly_sum = df2.groupby(df2['DateTime'].dt.month)["total_energy_consumption"].sum()
x=list(range(1,13))
sns.barplot(x=x,y=monthly_sum)
plt.title("Monthly Energy Consumption")
plt.show()
```


    
![png](output_20_0.png)
    


Here are the plots. The first plot is using the new.app4. It shows the hourly energy consumption. We can see cycle in the energy use. Each cycle is one day. Between each day. There are some days where is energy comsumption is lower than others. Those are the weekends. There is also almost no energy consumption for the last part. This can be an indication that the system is shut down and no longer consume energy. The next two plots are constructed using the other dataset. The second plot is hourly energy consumption without the weekends. The energy consumption still appear to be in cycle for each day. There is rarely days that have very low energy consumption as the weekend are removed. From this, we can also see a general trend that energy use is high at the begining, then lowered to some constant in the middle and finally raise again at the end. This trend is more clearly captured by the third plot. Here we plot the energy consumption for each month. The energy use is high for the first three month and last month. This might mean that the system is operating at a higher rate from December to March. 

## Assignment 3: EDA and forecast model


```python
timeserie = pd.read_excel ('Assignment 3 - timeseries_data.xlsx')
```

This is the date we imported. There are some missing values in the data. Those values are dropped.


```python
timeserie.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DATETIME</th>
      <th>HB_NORTH (RTLMP)</th>
      <th>ERCOT (WIND_RTI)</th>
      <th>ERCOT (GENERATION_SOLAR_RT)</th>
      <th>ERCOT (RTLOAD)</th>
      <th>HOURENDING</th>
      <th>MARKETDAY</th>
      <th>PEAKTYPE</th>
      <th>MONTH</th>
      <th>YEAR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2017-01-01 01:00:00</td>
      <td>23.3575</td>
      <td>2155.31</td>
      <td>0.0</td>
      <td>29485.791355</td>
      <td>1</td>
      <td>2017-01-01</td>
      <td>OFFPEAK</td>
      <td>JANUARY</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2017-01-01 02:00:00</td>
      <td>21.4650</td>
      <td>2313.81</td>
      <td>0.0</td>
      <td>28911.565913</td>
      <td>2</td>
      <td>2017-01-01</td>
      <td>OFFPEAK</td>
      <td>JANUARY</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2017-01-01 03:00:00</td>
      <td>20.7350</td>
      <td>2587.68</td>
      <td>0.0</td>
      <td>28238.258175</td>
      <td>3</td>
      <td>2017-01-01</td>
      <td>OFFPEAK</td>
      <td>JANUARY</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017-01-01 04:00:00</td>
      <td>20.2700</td>
      <td>2748.65</td>
      <td>0.0</td>
      <td>27821.000513</td>
      <td>4</td>
      <td>2017-01-01</td>
      <td>OFFPEAK</td>
      <td>JANUARY</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2017-01-01 05:00:00</td>
      <td>20.1200</td>
      <td>2757.49</td>
      <td>0.0</td>
      <td>27646.942413</td>
      <td>5</td>
      <td>2017-01-01</td>
      <td>OFFPEAK</td>
      <td>JANUARY</td>
      <td>2017</td>
    </tr>
  </tbody>
</table>
</div>



We start by smoothing the data. The method we adopt is Exponential Smoothing. This will reduce the effect of cycles in timeserie and make the data more smooth. Below are line plots for each column in the timeserie after smoothing.


```python
#Visualize each data
sns.lineplot(x="DATETIME", y="HB_NORTH (RTLMP)", data=timeserie)
plt.gca().set_xticklabels([])
plt.title("RTLMP")
plt.show()
```


    
![png](output_27_0.png)
    



```python
sns.lineplot(x="DATETIME", y="ERCOT (WIND_RTI)", data=timeserie)
plt.gca().set_xticklabels([])
plt.title("WIND_RTI")
plt.show()
```


    
![png](output_28_0.png)
    



```python
sns.lineplot(x="DATETIME", y="ERCOT (GENERATION_SOLAR_RT)", data=timeserie,linewidth=1)
plt.gca().set_xticklabels([])
plt.title("GENERATION_SOLAR_RT")
plt.show()
```


    
![png](output_29_0.png)
    



```python
sns.lineplot(x="DATETIME", y="ERCOT (RTLOAD)", data=timeserie,linewidth=1)
plt.gca().set_xticklabels([])
plt.title("RTLOAD")
plt.show()
```


    
![png](output_30_0.png)
    


We also produce a heat map to see the correlations betweem each variable. High correlation between predictors and cause problem is contructing the forcasting model. The variable we are predicting is RTLMP, others are predictors. From the graph, we can see that none of predictors are closely correlated. Only RTLOAD and GENERATION_SOLAR_RT have a 0.46 correlation which is still at an acceptable level.


```python
#Correlation
ax = sns.heatmap(timeserie.loc[:,["HB_NORTH (RTLMP)","ERCOT (WIND_RTI)","ERCOT (GENERATION_SOLAR_RT)","ERCOT (RTLOAD)"]].corr(), annot=True)
```


    
![png](output_32_0.png)
    



```python
#Forcasting model
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
```


```python
timeserie=timeserie.dropna()
X=timeserie.loc[:,["ERCOT (WIND_RTI)","ERCOT (GENERATION_SOLAR_RT)","ERCOT (RTLOAD)"]]
y=timeserie.loc[:,"HB_NORTH (RTLMP)"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
model = LinearRegression()
model.fit(X_train, y_train)
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)
train_error = mean_squared_error(y_train, y_train_pred)
test_error = mean_squared_error(y_test, y_test_pred)
```

For the last part. We create a linear regression model. The choose 0.8 the data as train and 0.2 as testing. Here are the training and testing error.

Training error:


```python
train_error
```




    195.68344917182526



Testing error:


```python
test_error
```




    132.7135399784833




```python

```
